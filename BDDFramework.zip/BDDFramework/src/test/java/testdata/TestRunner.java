package testdata;





import io.cucumber.junit.*;

import org.junit.runner.RunWith;

import io.cucumber.junit.CucumberOptions;




@RunWith(Cucumber.class)
@CucumberOptions
(
		features="./src/test/resources/features",
		glue = "stepDefinition",
		dryRun=false,
		plugin= {"pretty", "html:target/cucumber-report.html"},
		monochrome=true
		)
public class TestRunner {

	/*@CucumberOptions(features="src/test/java/cucumber",glue="rahulshettyacademy.stepDefinitions",
			monochrome=true, tags = "@Regression", plugin= {"html:target/cucumber.html"})
			public class TestNGTestRunner extends AbstractTestNGCucumberTests{

				
			}*/
	

	
}
