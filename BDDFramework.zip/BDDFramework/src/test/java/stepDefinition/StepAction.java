package stepDefinition;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import pageObjects.AddCartPage;
import pageObjects.LoginPage;
import pageObjects.YourCartPage;
import utilities.AbstractUtility;


public class StepAction{

	public LoginPage lp;
	public WebDriver driver;
	public AddCartPage addCart;
	
	@Given("User is on Login Page")
	public void user_is_on_login_page() {
	    // Write code here that turns the phrase above into concrete actions
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--disable-search-engine-choice-screen");
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(chromeOptions);
		//System.setProperty("webdriver.chrome.driver",System.getProperty("User.dir")+"//Driver/chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver","C:/Users/tasmi/eclipse-workspace/TestNGFramework/Drivers/chromedriver.exe");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().window().maximize();
		driver.get("https://www.saucedemo.com/");
		System.out.println("Launch Success");
		lp=new LoginPage(driver);
		addCart=new AddCartPage(driver);
	}

	@When("User enters {string} and {string}")
	public void user_enters_username_and_password(String username, String password) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions

		lp.Login(username, password);
		//System.out.println(driver.getTitle());
		System.out.println("Login Credential Enter Success");
	}

	@When("Clicks on Login Butoon")
	public void clicks_on_login_butoon() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	    lp.Submit();
	    System.out.println("Submit Test Success");
	    lp.quit();
	}

	@Then("User is navigated to Sag Demo Page")
	public void user_is_navigated_to_sag_demo_page() {
	    // Write code here that turns the phrase above into concrete actions
		
		System.out.println("User is navigated to Sag Demo Page");
	}

	@Then("Message displayed Login Successfully")
	public void message_displayed_login_successfully() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("User is navigated to Sag Demo Page");
	}

	@When("user logs clicks on add to cart")
	public void user_logs_clicks_on_add_to_cart() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		
		//addCart.AddCart();
		
		System.out.println("Add cart Test Success");
	}

	@When("Item is added in Shopping Cart")
	public void item_is_added_in_shopping_cart() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Add cart Test Success");
	}

	@When("user logs out from application")
	public void user_logs_out_from_application() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Add logout Test Success");
	}

	@Then("Message displayed Logout successfully")
	public void message_displayed_logout_successfully() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Add logout Test Success");
	}

	@Then("Browser quit by driver")
	public void browser_quit_by_driver() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Add logout Success");
		
	}



	
}
