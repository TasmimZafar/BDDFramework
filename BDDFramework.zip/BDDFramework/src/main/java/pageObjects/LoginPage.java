package pageObjects;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import utilities.AbstractUtility;

public class LoginPage extends AbstractUtility{

	WebDriver driver;
	
	public LoginPage (WebDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name="user-name")
	WebElement username1;
	
	@FindBy(id="password")
	WebElement password1;
	
	@FindBy(id="login-button")
	WebElement submitbtn;
	
	
	public void Login(String username,String password) throws InterruptedException
	{
		Thread.sleep(1000);
		WaitForElementToAppear(username1);
		username1.click();
		username1.sendKeys(username);
		password1.sendKeys(password);
		WaitForElementToAppear(submitbtn);
		Thread.sleep(2000);
		
	}
	
	public void Submit() throws InterruptedException
	{
		submitbtn.click();
		Thread.sleep(1000);
	}
	public void quit()
	{
		
		driver.quit();
		
	}
}
	