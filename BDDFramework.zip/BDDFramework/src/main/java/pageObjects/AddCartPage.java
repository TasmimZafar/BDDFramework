package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import utilities.AbstractUtility;

public class AddCartPage extends AbstractUtility{

	WebDriver driver;
	
	public AddCartPage (WebDriver driver) 
	{   super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath="//button[contains(text(),'Add to cart')][1]")
	WebElement addbackpack;
	
	@FindBy(className = "shopping_cart_link")
	WebElement shoppingCart;
	
	
	public void AddCart() throws InterruptedException
	{
		
		
		Thread.sleep(1000);
		WaitForElementToAppear(addbackpack);
		addbackpack.click();
		//Thread.sleep(2000);
		//WaitForElementToAppear(addJacket);
		//Thread.sleep(5000);
		Thread.sleep(1000);
		WaitForElementToAppear(shoppingCart);
		shoppingCart.click();
		//Thread.sleep(5000);
		
	}
}
	